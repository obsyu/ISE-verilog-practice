The following files were generated for 'samp_ram' in directory 
C:\cases\12\original\wave_gen_ver_s6\ipcore_dir\

blk_mem_gen_ds512.pdf:
   Please see the core data sheet.

samp_ram.asy:
   Graphical symbol information file. Used by the ISE tools and some
   third party tools to create a symbol representing the core.

samp_ram.ngc:
   Binary Xilinx implementation netlist file containing the information
   required to implement the module in a Xilinx (R) FPGA.

samp_ram.sym:
   Please see the core data sheet.

samp_ram.v:
   Verilog wrapper file provided to support functional simulation.
   This file contains simulation model customization data that is
   passed to a parameterized simulation model for the core.

samp_ram.veo:
   VEO template file containing code that can be used as a model for
   instantiating a CORE Generator module in a Verilog design.

samp_ram.vhd:
   VHDL wrapper file provided to support functional simulation. This
   file contains simulation model customization data that is passed to
   a parameterized simulation model for the core.

samp_ram.vho:
   VHO template file containing code that can be used as a model for
   instantiating a CORE Generator module in a VHDL design.

samp_ram.xco:
   CORE Generator input file containing the parameters used to
   regenerate a core.

samp_ram_readme.txt:
   Text file indicating the files generated and how they are used.

samp_ram_flist.txt:
   Text file listing all of the output files produced when a customized
   core was generated in the CORE Generator.


Please see the Xilinx CORE Generator online help for further details on
generated files and how to use them.

